import React from 'react'
import AddTodo from './components/AddTodo'
import VisibleTodoList from './components/VisibleTodoList'

const App = () => (
  <div>
    <AddTodo />
    <VisibleTodoList />
  </div>
)

export default App