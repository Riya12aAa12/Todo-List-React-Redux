import React from 'react'
import { addTodo, deleteTodo } from '../actions'

const Todo = ({ addTodo, text, id }) => (
  <li>
    <span className="list-view">{text}</span>
    <button className="delete" onClick={this.props.addTodo.bind(this)}>Delete Id: {id}</button>
  </li>
)




export default Todo